# [Título del Sitio Web]

[Título del Sitio Web] es un sitio web dedicado a conectar a la Universidad Metropolitana
y a sus estudiantes de manera íntegra y consistente, creando un nexo entre las agrupaciones
estudiantiles y la comunidad general de la institución.